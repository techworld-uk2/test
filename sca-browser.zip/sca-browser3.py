from selenium import webdriver
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.by import By
import pandas as pd
import time
import subprocess
import random  # Ensure this import is included



start_time = time.time()

# Define a single user agent
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.198 Safari/537.36"

def flush_dns_windows():
    try:
        subprocess.run(["ipconfig", "/flushdns"], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError as e:
        print("Error has Occurred")

# Set up Selenium WebDriver for Firefox with a given user agent
def get_driver():
    firefox_options = Options()
    firefox_options.add_argument("--disable-gpu")
    firefox_options.add_argument("--no-sandbox")
    firefox_options.set_preference("general.useragent.override", USER_AGENT)

    # Path to your geckodriver executable
    service = Service('geckodriver.exe')  # Replace with the path to your geckodriver
    driver = webdriver.Firefox(service=service, options=firefox_options)
    return driver

def set_user_agent(driver, user_agent):
    profile = FirefoxProfile(driver.capabilities['moz:firefoxOptions']['prefs'])
    profile.set_preference("general.useragent.override", user_agent)
    driver.profile = profile

# Function to fetch content from a URL
def fetch_content(driver, url):
    try:
        driver.get(url)
        time.sleep(2)  # Wait for the page to load
        
        # Check for unusual traffic warning
        content = driver.page_source
        if "Our systems have detected unusual traffic from your computer network" in content:
            print("Unusual traffic detected. Please interact with the page to continue.")
            input("Press Enter after you've interacted with the page...")
            
            time.sleep(1)  # Wait again for the page to load
        
        div = driver.find_element(By.CSS_SELECTOR, "div[style='align-content: center; background-color: #fff8f8; border: 2px solid #ff1210; padding: 10px ; border-radius: 5px;']")
        if div:
            content = div.text.strip()
            single_line_content = ' '.join(line.strip() for line in content.split("\n") if line.strip())
            return single_line_content
        else:
            return "Div with the specified style not found."
    except Exception as e:
        return f"Error fetching content"

def click_random_element(driver):
    # Find all clickable elements
    clickable_elements = driver.find_elements(By.CSS_SELECTOR, '*:not([class*="hidden"])')
    
    if not clickable_elements:
        print("No clickable elements found.")
        return
    
    # Randomly select one element
    element = random.choice(clickable_elements)
    
    try:
        element.click()
        
    except Exception as e:
        print(f"Error clicking element")

# Function to get a random delay between 2 to 4 seconds
def get_random_delay():
    return random.uniform(1, 2)

# Base URL
base_url = "https://webcache.googleusercontent.com/search?q=cache:https://mvnrepository.com/artifact/"

# Load the Excel file
excel_path = "components.xlsx"  # Replace with your actual file path
df = pd.read_excel(excel_path, engine='openpyxl')

# Ensure the 'Tester Comments' column is of type string
df['Tester Comments'] = df['Tester Comments'].astype(str)

# Initialize WebDriver
driver = get_driver()

# Process each row in the DataFrame
for index, row in df.iterrows():
    component = row['Components']
    url = base_url + component
    
    # Display the component being requested
    print("----------------------------------------------------------")
    print(f"Row: {index + 0}, Component: {component}")  # Add 1 to index for 1-based row numbers

    
    fetched_content = fetch_content(driver, url)
    df.at[index, 'Tester Comments'] = fetched_content
    
    print(fetched_content)
    print("--------------------------------------------------------")
    # Click on a random element on the page
    click_random_element(driver)
    
    # Apply a random delay between 2 to 4 seconds
    delay = get_random_delay()
    print(f"Waiting for {delay:.2f} seconds...")
    time.sleep(delay)
    flush_dns_windows()

# Save the updated DataFrame back to Excel
df.to_excel(excel_path, index=False, engine='openpyxl')
print("**********************************************************")
print("Excel File saved Successfully")

end_time = time.time()
execution_time = end_time - start_time
print("**********************************************************")
print(f"Execution time: {execution_time:.2f}seconds")


# Close the driver after all requests are completed
driver.quit()
